#!/usr/bin/env bash

JAR_DIR="$(cd "$(dirname "$0")" && pwd)"
JAR="$JAR_DIR/user-import-1.0.jar"

if [ -z "$1" ]; then
  echo "$0 /path/to/config.properties (required to run the code.) "
  exit 1
fi

CONFIG_PATH="$1"

java -Dconfig.file="$CONFIG_PATH" -jar "$JAR"
